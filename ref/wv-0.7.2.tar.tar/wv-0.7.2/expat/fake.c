/* automake-1.4-p5 requires there to be a source file in this directory
 * so here it is
 */
int wv_expat_fake () { return 0; }
